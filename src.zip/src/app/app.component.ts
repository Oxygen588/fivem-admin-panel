import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Live Screen', url: '/folder', icon: 'browsers' },
    { title: 'Administration', url: '/administration', icon: 'accessibility' },
    { title: 'Settings', url: '/settings', icon: 'ellipsis-horizontal-circle' },
    { title: 'Bans', url: '/bans', icon: 'hand-right' },
  
  ];
  constructor() {}
}
