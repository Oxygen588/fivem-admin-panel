import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;
  data:any;
  ip:any;
  isPopoverOpen:any;
  reasonban:any;
  apik:any;
  constructor(private http: HttpClient,private activatedRoute: ActivatedRoute) { }
  kick(data){
    console.log(data[0])
    let resp =  this.http.get("http://"+this.ip+":3000/doit/"+"http://"+this.ip+":30120/vrp_livescreen/kick:"+data[0]+"/apik:"+this.apik+"/reason:"+this.reasonban)
    resp.subscribe((data)=> this.data=data);
    console.log("http://"+this.ip+":30120/vrp_livescreen/kick:"+data[0]+"/apik:"+this.apik)
  }
  ban(data){
    console.log(data[0])
    let resp =  this.http.get("http://"+this.ip+":3000/doit/"+"http://"+this.ip+":30120/vrp_livescreen/ban:"+data[0]+"/apik:"+this.apik+"/reason:"+this.reasonban)
    resp.subscribe((data)=> this.data=data);
    console.log("http://"+this.ip+":30120/vrp_livescreen/kick:"+data[0]+"/apik:"+this.apik)
  }
  ngOnInit() {
    this.isPopoverOpen = true;
    this.ip =localStorage.getItem("ipaddress")
    this.apik =localStorage.getItem("apikey")
    let resp= this.http.get("http://"+this.ip+":3000/getplayers")
    resp.subscribe((data)=> this.data=data);
    resp.subscribe((data)=> console.log(data));
    
  }

}
