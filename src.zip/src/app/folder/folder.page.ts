import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;
  Topicuri : string;
  ip:any;
  iframeSrc:any;
  url:any;
  constructor(private sanitizer: DomSanitizer,private activatedRoute: ActivatedRoute) {
    let id = localStorage.getItem("ipaddress");
    let apik = localStorage.getItem("apikey");
    let url = `http://`+id+`/iframeee.html?cod=`+apik;
    this.iframeSrc = this.sanitizer.bypassSecurityTrustResourceUrl(url);
   }

  ngOnInit() {
    this.ip = this.ip =localStorage.getItem("ipaddress")
  }

}
