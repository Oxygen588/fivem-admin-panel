import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;
  ipaddress:any;
  apikey:any;
  ip:any;
  api:any;
  data:any;
  constructor(private http: HttpClient,private activatedRoute: ActivatedRoute) { }
  unban(data){
    console.log(data[0])
    let resp =  this.http.get("http://"+this.ip+":3000/doit/"+"http://"+this.ip+":30120/vrp_livescreen/deb:"+data+"/apik:"+this.apikey)
    resp.subscribe((data)=> this.data=data);

  }
  ngOnInit() {
    this.apikey = localStorage.getItem("apikey")
    this.ip =localStorage.getItem("ipaddress")
    let resp= this.http.get("http://"+this.ip+":3000/doit/"+"http://"+this.ip+":30120/vrp_livescreen/getbplayers/")
    resp.subscribe((data)=> this.data=data);
    resp.subscribe((data)=> console.log(data));
  }

}
