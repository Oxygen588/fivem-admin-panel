import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  public folder: string;
  ipaddress:any;
  apikey:any;
  ip:any;
  api:any;
  constructor(private http: HttpClient,private activatedRoute: ActivatedRoute) { }
  updatedata(){
 

    if (this.api !=null ){
    localStorage.setItem("apikey", this.api);
    }
    if (this.ip!=null ){
      localStorage.setItem("ipaddress", this.ip);
      }
  }
  ngOnInit() {
    this.ipaddress = localStorage.getItem("ipaddress");
    if (this.ipaddress == null){
    localStorage.setItem("ipaddress", '0.0.0.0');
    }
    this.ipaddress = localStorage.getItem("ipaddress");
    this.apikey = localStorage.getItem("apikey");
    if (this.apikey == null){
    localStorage.setItem("apikey", '1231531234');
    }
    this.apikey = localStorage.getItem("apikey");
  }

}
