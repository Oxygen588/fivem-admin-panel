const fs = require('fs');                  

const request = require('request');
var cmd=require('node-cmd');

let DISCusers = [];

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
PORT = 3000
var cors = require('cors')
server_cache_location = 'C:/Users/user/Desktop/svname/cache/';



var express = require('express');
var app = express();

app.use(cors())
app.get('/getplayers', function (req, res) {
    request('http://localhost:30120/vrp_livescreen/getplayers', function (error, response, body) {
  res.send(body)
});

 })
 app.get('/doit/:urlToShorten(*)', function (req, res) {

    request(req.params.urlToShorten, function (error, response, body) {
        res.send(body)
      });

 })







 var server = app.listen(PORT, function () {
    var host = server.address().address
    var port = server.address().port
    
    //console.log("Example app listening at http://%s:%s", host, port)
 })









userscode = {["test"] : true}





const imageToBase64 = require('image-to-base64');





function verifyit(what){
    try {
        if (fs.existsSync(what)) {
        return true
        }
    } catch(err) {
        return false
    }
}
    
const videousers = [];

var http = require('http');

var WebSocketServer = new require('ws');

// list of users
var CLIENTS = [];
var id;
let users = [];
let usersws = [];
// web server is using 8081 port
var webSocketServer = new WebSocketServer.Server({ port: 9898 });

// check if connection is established F:\DEVIL\cache
webSocketServer.on('connection', function (ws) {
    let name = "";
    id = ws;
    //console.log("con")
    tose = "";
    view = null;
    last30 = null;
    
    ws.on('message', function (message) {
        

        //console.log('received: %s', message[0]);
        //console.log(message)
        
        var received = JSON.parse(message);
        ggg = 1
        last30 = null;
        view = received.view;
        console.log(received.cod)
        last30 = received.last30;
        if (userscode[received.cod] == true){
        //console.log(DISCusers[received.disc].pass + " ---- "+ received.Pass)

                                cmd.run("curl -v http://localhost:30120/vrp_livescreen/view:"+received.view);
                               // console.log("view")
                            function doitwwait1(){
                        
                                setTimeout(function(){
                        
                                    
                                        //console.log(view)

                                        if (view != null){
                                    doitwwait1();
                                        }
                                   
                                        
                                       
                                      
                                                if (verifyit(server_cache_location+received.view+'.jpg')){
                                                            imageToBase64(server_cache_location+received.view+'.jpg') // Image URL
                                                            .then(
                                                                (response) => {
                                                                  //  console.log("asd")
                                                                    ws.send(JSON.stringify([response,received.view])); // "iVBORw0KGgoAAAANSwCAIA..."
                                                                }
                                                            )
                                                            .catch(
                                                                (error) => {
                                                                //   console.log(error); // Logs an error if there was one
                                                                }
                                                            )
                                                }
                                      
                                  
                                  



                                  
                                
                        
                                }, 100);
                        
                                
                            };
                            doitwwait1();
                        }
    });
    


    ws.on('close', function () {



        //console.log(name + " left the chat");
        users[name] = null;




        //console.log('user ' + received.name + ' left chat');

    });

});





















































































































