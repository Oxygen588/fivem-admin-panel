loadFile = LoadResourceFile(GetCurrentResourceName(), "./data.json")
information = {}
information.bans = {}

--SaveResourceFile(GetCurrentResourceName(), "./data.json", json.encode(information), -1)
loadFile = json.decode(loadFile)
----print(loadFile.bans)

users = {}


apikeys = {
    ["test"] = true,
    ["test1"] = true,
    ["test2"] = true,
    ["test3"] = true
}


newUsers = {}
SetHttpHandler(function(req, res)
    local path = req.path
    loadFile = LoadResourceFile(GetCurrentResourceName(), "./data.json")
    loadFile = json.decode(loadFile)
    if string.find(req.path, "viewasd") then
        cod = req.path:gsub(".*/viewasd:", "")

        newUsers[cod] = true
        res.send("oc")
        Wait(2400000)
        newUsers[cod] = false

    end
    if string.find(req.path, "view") then
        cod = req.path:gsub(".*/view:", "")
        newUsers[cod] = true
        res.send("oc")
        Wait(2400000)
        newUsers[cod] = false
    end
    if string.find(req.path, "getplayers") then
        data = {}
        for _, playerId in ipairs(GetPlayers()) do
            local name = GetPlayerName(playerId)
            ----print(('Player %s with id %i is in the server'):format(name, playerId))
            table.insert(data, { playerId, name })
        end
        res.send(json.encode(data))

    end
    if string.find(req.path, "getbplayers") then

        res.send(json.encode(loadFile.bans))

    end
    if string.find(req.path, "bans") then
        data = {}
        for _, playerId in ipairs(GetPlayers()) do
            local name = GetPlayerName(playerId)
            ----print(('Player %s with id %i is in the server'):format(name, playerId))
            table.insert(data, { playerId, name })
        end
        res.send(json.encode(data))

    end
    if string.find(req.path, "deb") then
        cod = req.path:gsub(".*/deb:", "")
        cod = cod:gsub("/.*", "")
        cod1 = req.path:gsub(".*/apik:", "")
        cod1 = cod1:gsub("/.*", "")
        if apikeys[cod1] == true then
            ----print("deban " .. cod)
            for index, value in pairs(loadFile.bans) do
                if (type(value[1]) == "string") then
                    if value[1] == cod then
                        loadFile.bans[index] = nil
                        SaveResourceFile(GetCurrentResourceName(), "./data.json", json.encode(loadFile), -1)
                        break
                    end
                end
            end
        end
    end
    if string.find(req.path, "ban") then

        cod = req.path:gsub(".*/ban:", "")
        cod = cod:gsub("/.*", "")
        cod1 = req.path:gsub(".*/apik:", "")
        cod1 = cod1:gsub("/.*", "")
        cod2 = req.path:gsub(".*/reason:", "")
        ----print(cod2 .. " - " .. cod1 .. " - " .. cod)
        if apikeys[cod1] == true then
            --print("dropping" .. cod)
            --print(GetPlayerToken(cod, 0))
            for var = 0, GetNumPlayerIdentifiers(cod) do
                if GetPlayerIdentifier(cod, var) ~= nil then
                    table.insert(loadFile.bans, { GetPlayerIdentifier(cod, var), true, GetPlayerName(cod), cod2 })
                end
            end
            DropPlayer(cod, "You have been kicked!Reason:" .. cod2)
            SaveResourceFile(GetCurrentResourceName(), "./data.json", json.encode(loadFile), -1)
        end
        --TempBanPlayer(cod,"You have been banned!")
        --DropPlayer(cod,"You have been banned!")
        res.send("oc")
    end
    if string.find(req.path, "kick") then
        cod = req.path:gsub(".*/kick:", "")
        cod = cod:gsub("/.*", "")
        cod1 = req.path:gsub(".*/apik:", "")
        cod1 = cod1:gsub("/.*", "")
        cod2 = req.path:gsub(".*/reason:", "")
        --print("-" .. cod .. "-")
        if apikeys[cod1] == true then
            --print("dropping" .. cod)
            DropPlayer(cod, "You have been kicked! Reason:" .. cod2)
        end
        --TempBanPlayer(cod,"You have been banned!")
        --DropPlayer(cod,"You have been banned!")
        res.send("oc")
    end
    return
end)




RegisterCommand('spawnzombie', function(source, args)
    --print(source)
end)
cat = 0
Citizen.CreateThread(function()
    while true do
        Wait(100)
        cat = cat + 1

        for k, v in pairs(newUsers) do
            ----print(newUsers[k])
            if (newUsers[k] == true) then

                if cat > 5000 then
                    newUsers[k] = false
                end
                ----print(k)

                exports['screenshot-basic']:requestClientScreenshot(k, {
                    fileName = 'cache/' .. k .. '.jpg'
                }, function(err, data)
                    --print(err)
                end)


            end
        end
        if cat > 5000 then
            cat = 0
        end
    end
end)
AddEventHandler('playerConnecting', function(name, setReason)
    local loadFile = LoadResourceFile(GetCurrentResourceName(), "./data.json")
    loadFile = json.decode(loadFile)
    for index, value in pairs(loadFile.bans) do
        if (type(value[1]) == "string") then
            ----print(value[1])
            for var = 0, GetNumPlayerIdentifiers(source) do
                if GetPlayerIdentifier(source, var) == value then
                    --CancelEvent()
                    DropPlayer(source, "You are banned")
                end
            end
        end
    end
end)

local function OnPlayerConnecting(name, setKickReason, deferrals)
    local player = source
    local steamIdentifier
    local identifiers = GetPlayerIdentifiers(player)
    deferrals.defer()

    -- mandatory wait!
    Wait(0)

    deferrals.update(string.format("Hello %s.We are checking if you are banned.", name))
    banned = false
    local loadFile = LoadResourceFile(GetCurrentResourceName(), "./data.json")
    loadFile = json.decode(loadFile)
    reason = ""
    for index, value in pairs(loadFile.bans) do
        if (type(value[1]) == "string") then

            for var = 0, GetNumPlayerIdentifiers(player) do
                --print(GetPlayerIdentifier(player, var), value[1])
                if GetPlayerIdentifier(player, var) == value[1] then
                    reason = value[4]
                    --CancelEvent()
                    --print("banned")
                    banned = true
                end
            end
        end
    end

    -- mandatory wait!
    Wait(0)

    if banned then
        deferrals.done("You are banned.Reason:" .. reason)
    else
        deferrals.done()
    end
end

AddEventHandler("playerConnecting", OnPlayerConnecting)
